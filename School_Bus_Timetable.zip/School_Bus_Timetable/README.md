1) This project is a part of WeChat Official Account named CQU Wukong. Users can follow this account in Wechat to test this function.

2) I used spider based on python, Javascript and H5/CSS to implement this function. Since this project is based on Wechat, both android system and iOS can view it.

3) Other parts of this Wechat official account is not included in this project.

4) Business name: 校车时刻表 - 重庆大学(Scholl bus timetable - Chongqing University)

5) Detail of the business: same as above

6) Business address and hours: as the video shows

7) Contact information: 虎溪校区管委会 (Huxi Campus Administration)

8) Two videos show two mode of this application: vertical and horizontal modes.

