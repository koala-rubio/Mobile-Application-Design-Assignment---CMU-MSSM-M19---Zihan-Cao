# coding=utf-8

MONGO_URI = "localhost"
MONGO_PORT = 27017

GENERIC_MONGO_DB = "cqu_news"
JOB_MONGO_DB = "job_news"
ACADEMIC_MONGO_DB = "academic_news"

GENERIC_COLLECTION_NAME = "NewsItem"
JOB_COLLECTION_NAME = "JobNewsItem"
ACADEMIC_COLLECTION_NAME = "AcademicNewsItem"
